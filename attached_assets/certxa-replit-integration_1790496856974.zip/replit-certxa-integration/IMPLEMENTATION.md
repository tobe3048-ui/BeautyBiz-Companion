# Native implementation guide

## Required packages and build

- Use `@stripe/stripe-terminal-react-native`.
- Mount `StripeTerminalProvider` at the app root.
- Use Expo SecureStore for the Certxa bearer token.
- Use a custom Expo development/EAS build. Expo Go and web preview cannot run the native Stripe Terminal module.
- Configure Tap to Pay on iPhone entitlement/Apple approval for iOS.
- Configure the Android permissions required by the Stripe Terminal SDK for the selected discovery method.

## Token provider

The provider's token callback must call `POST /api/payments/terminal/connection-token` through the authenticated Certxa API client and return only the response's `secret` value.

Do not cache Terminal connection-token secrets. Let the Stripe Terminal SDK request new short-lived tokens through the callback.

## Checkout sequence

1. Authenticate with `POST /api/solo/login` and securely store the returned bearer token.
2. Initialize Stripe Terminal.
3. Call `GET /api/payments/terminal/location`.
4. Discover and connect a real Tap to Pay reader using the returned `locationId`.
5. Call `POST /api/payments/terminal/create-payment-intent`.
6. Retrieve the PaymentIntent in the native SDK with its client secret.
7. Collect the payment method through the native reader.
8. Confirm/process the PaymentIntent through the SDK.
9. Call `POST /api/payments/terminal/capture-payment-intent` because the server creates manual-capture PaymentIntents.
10. Display immediate success only after the capture endpoint succeeds.
11. Cancel an unfinished intent with `POST /api/payments/terminal/cancel-payment-intent` when it is safe to void it.

Do not create a second PaymentIntent when retrying an authorized payment. Preserve the PaymentIntent ID and retry server capture to avoid duplicate charges.

## Existing request shape

The existing server expects `amountCents`, not `amount`, and currently expects numeric appointment IDs.

```json
{
  "amountCents": 4800,
  "currency": "usd",
  "appointmentId": 123,
  "clientName": "Example Client",
  "method": "tap_to_pay",
  "tipCents": 0,
  "discountCents": 0,
  "priorTenderedCents": 0
}
```

Supported method values currently include `tap_to_pay`, `m2`, and `card`.

## Error handling

- Treat 401 as an expired/invalid Certxa login and require login again.
- Surface the backend's `error` or `message` field without exposing raw secrets.
- Do not log bearer tokens, Terminal connection-token secrets, or PaymentIntent client secrets.
- Handle user cancellation separately from declines and network failures.
- Use idempotent capture retry behavior after native confirmation.

## Not available yet

There is no dedicated mobile payment-status endpoint in this contract. Use the immediate Terminal and capture responses for UI behavior. Do not invent a Replit-hosted status database; final webhook-driven state belongs to Certxa.
