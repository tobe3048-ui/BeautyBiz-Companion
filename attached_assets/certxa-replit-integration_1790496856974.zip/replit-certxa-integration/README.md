# Certxa Pro mobile integration packet

This packet contains the non-secret information needed to connect the Certxa Pro Expo app to the existing Certxa SaaS backend and Stripe Terminal.

## Production configuration

```env
EXPO_PUBLIC_API_BASE_URL=https://certxa.com
```

Do not add a Stripe secret key, Connect account ID, webhook secret, session secret, or database credential to the Expo app or Replit secrets.

## Included files

- `certxa-terminal.openapi.yaml` — authoritative API contract for the mobile login and Terminal endpoints.
- `certxa-api.ts` — reusable TypeScript API client with request/response types.
- `.env.example` — safe Expo runtime configuration.
- `IMPLEMENTATION.md` — native Stripe Terminal flow and integration requirements.

## Authentication

1. Send the professional's email and password to `POST /api/solo/login`.
2. Save the returned Certxa bearer token in Expo SecureStore.
3. Send `Authorization: Bearer <token>` on every protected request.
4. Never send or accept a Stripe connected-account ID from the mobile app. The backend derives the business and Stripe account from the authenticated Certxa user.

The bearer token currently expires after 30 days. On a 401 response, clear it and return the user to Certxa login.

## Existing Connect model

Certxa uses direct charges:

- Terminal connection tokens are created in the salon's connected Stripe account context.
- PaymentIntents are created on that same connected account.
- PaymentIntents use `card_present` and manual capture.
- Certxa applies its platform application fee server-side.
- Currency is currently USD and the expected operating country is the United States.

## Important backend constraints

The current payment endpoint verifies that an appointment belongs to the authenticated store, but it still accepts `amountCents` from the client. Before broad production release, Certxa should harden the backend so the authoritative total is recomputed from appointment/service/add-on/tax/discount data.

The current Connect webhook finalizes successful PaymentIntents. Full webhook-driven synchronization for failed/canceled intents, refunds, and disputes remains backend work and must not be simulated in the mobile app.

## Replit instruction

Use the existing Certxa HTTPS API. Do not create duplicate Stripe server routes in Replit. If the app requires a backend contract change, report the requested change so it can be implemented in the main Certxa backend.
