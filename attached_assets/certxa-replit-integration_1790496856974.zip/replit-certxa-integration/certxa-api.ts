export const CERTXA_API_BASE_URL =
  process.env.EXPO_PUBLIC_API_BASE_URL?.replace(/\/$/, "") || "https://certxa.com";

export interface CertxaUser {
  id: string;
  email?: string;
  role?: string;
  staffId?: number | null;
  [key: string]: unknown;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: CertxaUser;
}

export interface TerminalConnectionTokenResponse {
  secret: string;
}

export interface TerminalLocationResponse {
  locationId: string;
}

export type TerminalPaymentMethod = "tap_to_pay" | "m2" | "card";

export interface CreateTerminalPaymentIntentRequest {
  amountCents: number;
  currency?: "usd";
  appointmentId: number;
  clientName?: string;
  method: TerminalPaymentMethod;
  tipCents?: number;
  discountCents?: number;
  priorTenderedCents?: number;
}

export interface CreateTerminalPaymentIntentResponse {
  paymentIntentId: string;
  clientSecret: string;
  amount: number;
  currency: string;
}

export interface CaptureTerminalPaymentIntentResponse {
  success: true;
  paymentIntentId: string;
  status: string;
  amount: number;
}

export interface CancelTerminalPaymentIntentResponse {
  success?: true;
  [key: string]: unknown;
}

export class CertxaApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly payload?: unknown,
  ) {
    super(message);
    this.name = "CertxaApiError";
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  token?: string,
): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set("Accept", "application/json");
  if (options.body) headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const response = await fetch(`${CERTXA_API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  const payload = await response.json().catch(() => null) as Record<string, unknown> | null;
  if (!response.ok) {
    const message =
      (typeof payload?.error === "string" && payload.error) ||
      (typeof payload?.message === "string" && payload.message) ||
      `Certxa API request failed (${response.status})`;
    throw new CertxaApiError(message, response.status, payload);
  }
  return payload as T;
}

export function login(body: LoginRequest): Promise<LoginResponse> {
  return request<LoginResponse>("/api/solo/login", {
    method: "POST",
    body: JSON.stringify(body),
  });
}

export function createTerminalConnectionToken(
  token: string,
): Promise<TerminalConnectionTokenResponse> {
  return request<TerminalConnectionTokenResponse>(
    "/api/payments/terminal/connection-token",
    { method: "POST" },
    token,
  );
}

export function getTerminalLocation(token: string): Promise<TerminalLocationResponse> {
  return request<TerminalLocationResponse>(
    "/api/payments/terminal/location",
    { method: "GET" },
    token,
  );
}

export function createTerminalPaymentIntent(
  token: string,
  body: CreateTerminalPaymentIntentRequest,
): Promise<CreateTerminalPaymentIntentResponse> {
  return request<CreateTerminalPaymentIntentResponse>(
    "/api/payments/terminal/create-payment-intent",
    { method: "POST", body: JSON.stringify({ currency: "usd", ...body }) },
    token,
  );
}

export function captureTerminalPaymentIntent(
  token: string,
  paymentIntentId: string,
  method: TerminalPaymentMethod,
): Promise<CaptureTerminalPaymentIntentResponse> {
  return request<CaptureTerminalPaymentIntentResponse>(
    "/api/payments/terminal/capture-payment-intent",
    { method: "POST", body: JSON.stringify({ paymentIntentId, method }) },
    token,
  );
}

export function cancelTerminalPaymentIntent(
  token: string,
  paymentIntentId: string,
): Promise<CancelTerminalPaymentIntentResponse> {
  return request<CancelTerminalPaymentIntentResponse>(
    "/api/payments/terminal/cancel-payment-intent",
    { method: "POST", body: JSON.stringify({ paymentIntentId }) },
    token,
  );
}
